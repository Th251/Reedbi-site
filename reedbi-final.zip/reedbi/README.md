# Reedbi Homes (Firestore version)

## Files

| File | What it is |
|---|---|
| `src/index.html` | The readable source. **Edit this one.** Your settings are in the `reedbi-config` block near the bottom. |
| `public/index.html` | The built website: compressed code with its security fingerprint. **Upload this one.** Never edit it by hand. |
| `build.mjs` + `package.json` | The build. `npm install` once, then `npm run build` after every edit. It compresses the code, recomputes the fingerprint and writes it into the page and `firebase.json`. |
| `firestore.rules` | Firebase console → Firestore → Rules. Your existing rules plus a **RENTALS** section. |
| `firebase.json` | Security headers for Firebase Hosting. `npm run deploy` builds and deploys in one step. |
| `.github/` | GitHub Actions: security checks on every change, automatic deploy, weekly Dependabot updates. |
| `SECURITY.md`, `public/.well-known/security.txt` | Tell people how to report a security problem privately. Change the email if you use another one. |
| `.gitignore` | Keeps `node_modules` and any key files out of GitHub. |

## What visitors get (map-first, like Reedbi)

- **Phones:** opens on Home with listings on the left and the map on the right; compact header; the Full map tab gives a bigger map with swipeable cards.
- **The list follows the map:** moving or zooming the map shows only the places in view ("5 places in this map area", with Show all). Places at the same spot open as one list instead of zooming forever.
- **Contact:** your own WhatsApp number is not used anywhere. Site help goes to Instagram @reedbi_private_limited (floating button and footer). Example listings never open anyone's WhatsApp.
- **Live for everyone.** Once Firebase is connected, every visitor's map and list update the moment anyone posts, edits, marks occupied or removes a listing.
- **Google Maps links when posting.** Paste any full Google Maps link (place, pin, or `?q=lat,lng`) or plain coordinates; the dropped pin is used when the link has one. Short `maps.app.goo.gl` links must be opened first and the full address copied.
- **Your location.** The locate button shows a blue dot, sorts listings nearest first and adds "2 km from you" to each one. If the browser blocks location, a help panel explains how to allow it and offers quick city buttons. If location was already allowed, the blue dot appears on load.

- **Video tours.** When posting, owners can paste an Instagram reel/post, YouTube (including Shorts) or TikTok video link. It plays right on the listing, under the photos, and the listing gets a Video badge plus a "With video" filter. Nothing is shown when no link is added. Only the platform and video ID are saved; the player address is rebuilt from the ID, and the player loads only after the visitor taps play, inside a sandboxed frame. Owners can also add Instagram, YouTube and TikTok profile links; each button appears only if that link was added.

- Clicking a listing on a computer opens its details inside the left panel (back button or Esc returns to the list at the same spot) while the map centres on its pin. Details include a photo slider, key facts, a move-in cost estimate (first payment or first cheque plus deposit) and nearby places with distances.
- On computers: a scrolling panel of listings with prices on the left, the map on the right. Hovering a listing highlights its pin (or its group bubble); the pin button on each listing zooms the map to it; clicking a pin highlights and scrolls to its listing. Nearby pins are grouped into one bubble ("7 from AED 650"); click it to zoom in. In Arabic the whole layout mirrors.

- On phones the site opens on a full-screen map with price pins. A row of swipeable cards sits at the bottom: swiping a card highlights its pin and moves the map; tapping a pin brings its card into view.
- **Search this area** appears when you move the map, and filters to what is on screen.
- **Show my location** button, zoom buttons, and a small panel with counts per property type (tap one to filter), like the Reedbi category panel.
- Green **New** badges and pin dots for places posted in the last 24 hours.
- **Recently viewed** row, loading placeholders instead of a blank screen, a small vibration on taps (Android), a heart animation when saving, and a confetti burst when a listing goes live. Motion is turned off for people who set "reduce motion".

## Can people see the code? Yes, and that is normal

Every website's HTML and JavaScript is sent to the visitor's browser, including Google, Bayut and banks. Nobody can hide it. The build compresses and renames everything, so the public code is hard to read and copy, but that is a deterrent, not the protection. **Seeing the code does not let anyone change your website.** What protects a site is what happens on Google's side:

- **Your website files** can only be replaced by someone logged in to your Firebase/Google account. Protect that account (checklist below).
- **Your data** can only be changed in the ways `firestore.rules` allows, whatever a person does in their own browser.
- **Visitors' browsers** are protected by the headers and fingerprints in this version, so injected or altered scripts will not run.

## Owner accounts (no sign-up form)

- **Posting:** the owner types only their name and WhatsApp number. An account is created automatically in the background when they post (Firebase Anonymous sign-in). This needs, in Firebase console → Authentication: **Sign-in method → Anonymous: Enabled**, and **Settings → User actions → Enable create (sign-up): ticked**.
- **Use listings on any phone (optional):** in My listings the owner enters an email and taps the link Firebase sends. The email is linked to the same account, so they can edit or remove their listings from any phone. No password. This needs **Sign-in method → Email/Password: Enabled, with "Email link (passwordless sign-in)" on**, and **Settings → Authorized domains: add `reedbi.com` and `www.reedbi.com`**.
- **WhatsApp / Show number:** no sign-in at all; one number at a time, never a list.
- **SMS or WhatsApp codes** are not used: SMS needs the paid Blaze plan and is charged per message; WhatsApp codes need a paid WhatsApp Business provider and a server.

## Make listings live for everyone (Firebase, about 10 minutes)

The site is connected to project **reedbi-36a08** (config is in the `reedbi-config` block). Until the rules are published it shows example listings with a note; once they are, every listing is live for everyone.

1. **Config (done):** Firebase console → ⚙️ Project settings → Your apps → web app → Config. Paste it into the `reedbi-config` block at the bottom of `src/index.html` as `"firebase": { "apiKey": "...", "authDomain": "...", "projectId": "...", "storageBucket": "...", "messagingSenderId": "...", "appId": "..." }`, then `npm run build`.
2. **Sign-in:** Authentication → Sign-in method → turn on **Anonymous** (visitors post without a sign-up form; your current app already uses it).
3. **Rules:** Firestore → Rules → paste `firestore.rules` → Publish. Everything outside the RENTALS section is your existing file, unchanged.
4. **Smaller indexes (recommended):** Firestore → Indexes → Single field → Add exemption for collection `rentals`, field `cover`, and for `rentalPhotos`, field `photos`: turn off all indexing. Photos are never searched, so this saves storage and cost.
5. **App Check (recommended):** register reCAPTCHA Enterprise, put the site key in `appCheckSiteKey`, and enforce for Firestore once your existing app also sends App Check tokens.
6. Commit and push. Open reedbi.com in two different browsers: a listing posted in one appears in the other within a second, with a "Just posted" notice, without refreshing.

**What is stored where:** `rentals` (public listing with one small cover photo), `rentalPhotos` (full photos, loaded when a listing is opened), `rentalContacts` (phone numbers, one at a time, never listed), `rentalMeta` (10-minute posting limit), `rentalReports` (admins only). Photos are kept in Firestore itself, so **Firebase Storage and the paid Blaze plan are not needed**.

## Every listing on Google (automatic)

`scripts/build-pages.mjs` turns the live Firestore listings into plain pages Google can index:

- `/rent/<type>-<area>-<city>-<id>/` for each listing, e.g. `reedbi.com/rent/studio-al-karama-dubai-ab12…/`, titled like "Studio for rent in Al Karama, Dubai – AED 4,200/month". It includes the cover photo, facts, description, structured data for Google, and buttons to chat on WhatsApp or see it on the map (no phone number is on the page).
- `/rent/area/<area>-<city>/` for each area, e.g. "Rooms, bed spaces and flats for rent in Al Karama, Dubai".
- `/rent/` lists all areas, and `sitemap.xml` lists every page for Google.

The **Listing pages** GitHub workflow runs this every 30 minutes and commits the pages. Taken listings stay reachable but tell Google not to show them; removed listings disappear on the next run.

**Turn it on:** upload `scripts/build-pages.mjs` and `.github/workflows/listing-pages.yml`, then GitHub → Actions → Listing pages → **Run workflow** once. If your site files sit at the repository root rather than in `public/`, first add the repository variable `SITE_DIR` = `.`. Then submit `https://reedbi.com/sitemap.xml` in Google Search Console. New listings appear in Google typically within days.

**Bing, ChatGPT search and Copilot** are told about every new or changed page within minutes through IndexNow (key file `public/b642c4a0474b8ca2b0c80f5c1d49746d.txt`; keep it uploaded). Google has no equivalent for rentals and reads the sitemap instead. `llms.txt` gives AI assistants a plain summary of the site and its areas.

**Job safeguards:** network calls time out, oversized or duplicate data is ignored, and the job refuses to commit any file other than the generated pages, sitemap and llms.txt.

The generated pages contain no JavaScript at all, and every word a visitor typed is escaped, so a listing cannot inject anything into them.

## Getting found on Google, Instagram, Facebook and Maps

No website can make Google or Instagram show it automatically. These steps are what make reedbi.com appear when people search for rooms or share links:

1. **Upload the whole `public` folder**, not only index.html: `og.png` (the picture shown when a link is shared on WhatsApp, Facebook, Instagram or X), `robots.txt`, `sitemap.xml`, the icons and `site.webmanifest` (lets phones add Reedbi to the home screen).
2. **Google Search Console** (search.google.com/search-console): add `reedbi.com`, verify it with the DNS record it gives you, then submit `https://reedbi.com/sitemap.xml`. Google starts showing reedbi.com for searches like "bed space Karama" within days to weeks.
3. **Google Business Profile** (business.google.com): create "Reedbi" as an online real-estate service with the website reedbi.com. This is what puts Reedbi on Google Maps and in the business panel on Google.
4. **Bing Webmaster Tools** (bing.com/webmasters): import from Search Console in one click. It also feeds ChatGPT and Copilot search.
5. **Instagram @reedbi_private_limited**: add a profile photo, a bio ("Rooms, bed spaces and flats for rent in UAE. Post free") and put `https://reedbi.com` in the Website field. Post each new listing as a Reel with the reedbi.com link, using tags like #dubairooms #bedspacedubai #roomforrentdubai #sharjahrooms #partitiondubai.
6. **Facebook**: create a Reedbi page with the website link, and share listings in the big UAE room groups ("Room for rent Dubai", "Bed space Dubai", "Kerala people in UAE"). Every shared link shows the Reedbi preview picture.
7. **WhatsApp**: the Share button on every listing sends a ready-made message with the link. Owners sharing their own listings in groups is the fastest free advertising.
8. **Search box in Google**: the page tells Google that `https://reedbi.com/?q=studio karama` searches the site, so Google can show a search box for Reedbi, and you can share search links like that.

## Your hosting today

reedbi.com is served by **GitHub Pages**. The page's own security policy is active, and the page refuses to run inside another site's frame (clickjacking). GitHub Pages cannot send HSTS, X-Frame-Options or the other headers in `firebase.json`; add them with Cloudflare (Option B below) or move to Firebase Hosting (Option A).

## Using GitHub safely

### 1. Lock down the GitHub account and repository
1. **Two-factor authentication:** GitHub → Settings → Password and authentication. Use an authenticator app or passkey.
2. **Keep the repository public.** GitHub Pages on a free account only publishes public repositories (private needs GitHub Pro). This is safe: the site's code is visible in every browser anyway, and no secret is stored in it. Never commit service-account keys or passwords.
3. **Protect `main`:** Settings → Rules → Rulesets → New branch ruleset → target `main`: require a pull request, require the **Check** status to pass, block force pushes, block deletion.
4. **Security features:** Settings → Code security → turn on Dependabot alerts, Dependabot security updates, Secret scanning **and Push protection** (blocks a commit that contains a key), and Code scanning → CodeQL default setup.
5. **Actions permissions:** Settings → Actions → General → Workflow permissions: **Read repository contents**; untick "Allow GitHub Actions to create and approve pull requests". Allow only actions from GitHub and verified creators.
6. **Collaborators:** only people who need it, with "Write" not "Admin".

### 2. Pick how the site is hosted

**Option A: Firebase Hosting, deployed from GitHub (recommended).** Every security header in `firebase.json` is applied, and the rules deploy together with the site.
1. Google Cloud console → IAM → Service accounts → create `github-deployer` with only **Firebase Hosting Admin**, **Firebase Rules Admin** and **Cloud Storage for Firebase Admin**. Create a JSON key.
2. GitHub → Settings → Secrets and variables → Actions:
   - Secret `FIREBASE_SERVICE_ACCOUNT` = the whole JSON key. Then delete the key file from your computer.
   - Variables `DEPLOY_TARGET` = `firebase`, `FIREBASE_PROJECT_ID` = your project id.
3. Settings → Environments → `production` → add yourself as **Required reviewer**, so nothing goes live without your click.
4. Point reedbi.com to Firebase Hosting (Firebase console → Hosting → Add custom domain).

**Option B: GitHub Pages.** Simple, but Pages cannot send security headers. The page's own CSP still works; to add the rest, put the domain on Cloudflare (free):
1. Settings → Pages → Source: **GitHub Actions**. Variables `DEPLOY_TARGET` = `pages`, `SITE_DOMAIN` = `reedbi.com`. Tick **Enforce HTTPS**.
2. Cloudflare → your domain → Rules → Transform Rules → **Modify Response Header** → set the headers listed in `firebase.json` (Content-Security-Policy with `frame-ancestors 'none'`, Strict-Transport-Security, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, Cross-Origin-Opener-Policy).
3. Cloudflare → SSL/TLS: **Full (strict)**, Always Use HTTPS on, minimum TLS 1.2. Security → Bots: Bot Fight Mode on.
4. Publish `firestore.rules` from the Firebase console yourself (Pages cannot deploy it).

### 3. Everyday workflow
1. Edit `src/index.html` on a new branch, run `npm run build`, open a pull request.
2. The **Check** workflow builds the site and blocks the change if: a known vulnerable package is used, a private key is committed, the CSP or a script fingerprint is missing, `unsafe-inline` crept into scripts, or the deny-all Firestore rule was removed.
3. Merge, approve the `production` deployment, done. Firebase Hosting and GitHub Pages both keep previous releases if you need to roll back.

### Never put on GitHub
Service account keys, `.env` files, admin passwords, or anything from Firebase → Project settings → **Service accounts**. The web config in `reedbi-config` is fine to commit; it is public by design.

## Hardening built into the code

1. **Script fingerprints (SRI).** Leaflet and the five Firebase files are pinned to exact versions with sha384 fingerprints. If a CDN file is changed by anyone, the browser refuses to run it.
2. **Strict Content Security Policy** in both the page (`<meta>`) and the server headers. No `unsafe-inline` for scripts: the page's own script is allowed only by its sha256 fingerprint, so any script an attacker manages to inject is blocked. Plugins, `<base>` tricks and form hijacking are blocked; the site cannot be framed (clickjacking).
3. **Trusted Types policy.** Every HTML write goes through one gate that refuses script tags, event handlers and `javascript:` links. It runs in report-only mode first (see below).
4. **No user text is ever turned into HTML.** Everything people post is shown with `textContent`. Links are limited to https, Instagram, YouTube, WhatsApp and Google Maps.
5. **Settings are data, not code.** The `reedbi-config` block is parsed as JSON and every value is checked. A wrong or malicious value falls back to a safe default.
6. **Settings and labels are frozen** (`Object.freeze`), so other code on the page cannot change them.
7. **Photos are re-encoded** on the phone, which removes hidden GPS data.
8. **Phone numbers are not in public data.** They are fetched one at a time only when someone taps WhatsApp or Show number.
9. **Headers:** HSTS preload, nosniff, strict referrer, Permissions-Policy, X-Frame-Options DENY, Cross-Origin-Opener/Resource-Policy.

## Common mistakes the build now blocks

- **Anything typed before `<!doctype html>`** (even one character, such as a stray `2`). The browser then ignores the security policy and the page layout breaks. The build and the GitHub check both refuse it.
- **Uploading an unbuilt or hand-edited `public/index.html`.** The GitHub check fails unless the file matches `npm run build` exactly.
- **Script names leaking into the page.** The build wraps the script so none of its names become globals (a minified name had overwritten the map library). The GitHub check refuses an unwrapped script.
- **Declaring anything named `L` in the script.** `L` is the map library; overwriting it is what made the map blank. The build refuses it.
- **Windows line endings.** `.gitattributes` keeps every file in the repository with Unix line endings.

## After every edit

```bash
npm run build
```

The page only runs a script whose fingerprint matches the one in its security policy. The build updates both for you and stops with "Fingerprint mismatch, do not deploy" if anything is off. If you upload an unbuilt page, the browser blocks the script and no listings appear.

## Trusted Types: switch from report-only to enforce

After going live, open the site in Chrome, press F12, open Console, and use the site (map, post, WhatsApp). If there are **no** "Trusted Types" messages, move `require-trusted-types-for 'script'; trusted-types default goog#html recaptcha 'allow-duplicates'` from the `Content-Security-Policy-Report-Only` header into the main `Content-Security-Policy` header in `firebase.json`.

## Account and project checklist (this is what stops someone damaging the site)

1. **2-Step Verification** on every Google account with access to the Firebase project. Use a security key or authenticator app, not SMS.
2. **IAM:** Google Cloud console → IAM. Remove anyone who doesn't need access. Give helpers "Viewer" or "Firebase Hosting Admin" only, never "Owner".
3. **Restrict the API key:** Google Cloud console → APIs & Services → Credentials → the browser key → Application restrictions: Websites → `https://reedbi.com/*`, `https://www.reedbi.com/*`. API restrictions: only Firestore, Identity Toolkit, Token Service, Firebase App Check, Cloud Storage for Firebase.
4. **App Check** with reCAPTCHA Enterprise, enforced for Firestore and Storage. This stops scripts and bots using your config from outside your site. Enforce only once your existing Reedbi app also sends App Check tokens.
5. **Rules:** publish `firestore.rules`. Test in the Rules Playground: post a listing (allowed), read a phone number (allowed), edit someone else's listing (denied), list all of `rentalContacts` (denied).
6. **Backups:** Firestore → Disaster recovery → turn on Point-in-time recovery and daily scheduled backups, so any damage can be rolled back.
7. **Budget alert:** Billing → Budgets & alerts at a small amount, so a flood of fake traffic cannot run up a bill unnoticed.
8. **Auth abuse:** Authentication → Settings → keep "user account creation" limits on; consider requiring WhatsApp/SMS OTP before posting.
9. **Hosting history:** Firebase Hosting keeps every release; if a bad deploy happens, click Rollback.
10. **Domain:** turn on registrar lock and 2-step verification at your domain registrar, and enable DNSSEC.

## What the Firestore rules enforce

- Listings are public; phone numbers are kept apart in `rentalContacts`, readable one at a time, never as a list.
- Every field checked for type, size and allowed values; photos only from your own Storage; no extra fields.
- One new listing per account every 10 minutes.
- Only the owner edits, marks occupied or deletes; owners cannot add a verified badge, unhide a hidden listing or change the owner.
- One report per person per listing; only admins read reports.

## Note about your existing `/props` collection

It is readable by everyone. If those documents have a `phone` field, every number can be downloaded with one query. Moving numbers to a separate collection, as `rentalContacts` does, fixes it.

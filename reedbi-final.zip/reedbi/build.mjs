// Build: node build.mjs
// Reads src/index.html (readable source you edit), minifies the page script, computes its
// sha256 fingerprint, and writes public/index.html (what you upload) plus the same
// fingerprint into firebase.json. The Content Security Policy runs ONLY a script whose
// fingerprint matches, so always rebuild after editing src/index.html.
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { minify } from 'terser';

const SRC = 'src/index.html', OUT = 'public/index.html', FB = 'firebase.json';
const src = readFileSync(SRC, 'utf8').replace(/^\uFEFF/, '').replace(/\r\n/g, '\n');
if (!/^<!doctype html>\s*<html[^>]*>\s*<head>/i.test(src)) throw new Error('src/index.html must start with <!doctype html><html><head>. Remove anything typed before it.');
if (/\b(function|const|let|var|class)\s+L\b/.test(src)) throw new Error('Do not declare anything named L: it replaces the Leaflet map library and the map stops working.');
const SCRIPT = /<script>([\s\S]*?)<\/script>/g;
const blocks = [...src.matchAll(SCRIPT)];
if (blocks.length !== 1) throw new Error(`Expected exactly one inline <script>, found ${blocks.length}`);

// Wrap in a function so none of the page's names become window globals. Otherwise a
// minified name such as L can overwrite the Leaflet map library, and outside scripts or
// browser extensions cannot reach the page's internals either.
const wrapped = '(()=>{' + blocks[0][1] + '\n})();';
const { code } = await minify(wrapped, {
  toplevel: true, mangle: { reserved: ['L', 'firebase', 'trustedTypes'] }, compress: { passes: 2, drop_debugger: true },
  format: { comments: false, ascii_only: true }
});
const hash = 'sha256-' + createHash('sha256').update(code, 'utf8').digest('base64');

let html = src.replace(SCRIPT, () => '<script>' + code + '</script>');
html = html.replace(/<style>([\s\S]*?)<\/style>/, (_, css) => '<style>' + css
  .replace(/\/\*[\s\S]*?\*\//g, '').replace(/\s+/g, ' ').replace(/\s*([{};,>])\s*/g, '$1').trim() + '</style>');
html = html.replace(/<!--(?![\s\S]*?reedbi-config)[\s\S]*?-->\n?/g, '');      // keep only the settings note
html = html.replace(/'sha256-[A-Za-z0-9+/=]+'|'sha256-BUILD'/g, () => `'${hash}'`);
if (code.includes('\n')) throw new Error('Minified script must be one line');
writeFileSync(OUT, html);

const fb = readFileSync(FB, 'utf8').replace(/'sha256-[A-Za-z0-9+/=]+'/g, () => `'${hash}'`);
writeFileSync(FB, fb);

// Self-check: the fingerprint in both files must match the script actually written.
const written = [...readFileSync(OUT, 'utf8').matchAll(SCRIPT)][0][1];
const check = 'sha256-' + createHash('sha256').update(written, 'utf8').digest('base64');
if (check !== hash || !fb.includes(hash)) throw new Error('Fingerprint mismatch, do not deploy');
const out = readFileSync(OUT, 'utf8');
if (!out.startsWith('<!doctype html>')) throw new Error('Output must start with <!doctype html>');
if (out.indexOf('http-equiv="Content-Security-Policy"') > out.indexOf('</head>') && out.includes('</head>')) throw new Error('CSP meta must be inside <head>');
console.log(`Built ${OUT}: ${(html.length / 1024).toFixed(0)} KB, script ${hash}`);

# Security

Found a security problem in Reedbi? Email security@reedbi.com with the steps to reproduce it.
Please do not open a public GitHub issue for security problems. We reply within 3 working days.

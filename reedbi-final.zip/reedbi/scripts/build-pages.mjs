// Builds one Google-friendly page per listing, one page per area, and the sitemap.
//   node scripts/build-pages.mjs            (reads live listings from Firestore)
//   FIXTURE=listings.json node scripts/...   (reads a saved Firestore REST response instead)
// Env: SITE_DIR (default "public"), PROJECT_ID (default reedbi-36a08), SITE_URL (default https://reedbi.com)
//
// Security: the pages contain no JavaScript at all. Every value written by a visitor is
// HTML-escaped, ids and numbers are validated, cover photos must be real JPEGs, and phone
// numbers are never read (they live in rentalContacts, which this script does not touch).
import { mkdirSync, rmSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const SITE_DIR = process.env.SITE_DIR || 'public';
const PROJECT_ID = process.env.PROJECT_ID || 'reedbi-36a08';
const SITE = (process.env.SITE_URL || 'https://reedbi.com').replace(/\/$/, '');
const OUT = join(SITE_DIR, 'rent');

const TYPES = { studio: 'Studio', '1bhk': '1 BHK', '2bhk': '2 BHK', '3bhk': '3+ BHK', villa: 'Villa', room: 'Room', bedspace: 'Bed space', partition: 'Partition', office: 'Office / Shop', parking: 'Parking' };
const CUR = { AE: 'AED', SA: 'SAR', QA: 'QAR', OM: 'OMR', KW: 'KWD', BH: 'BHD', EG: 'EGP', JO: 'JOD', IN: 'INR' };
const COUNTRY = { AE: 'UAE', SA: 'Saudi Arabia', QA: 'Qatar', OM: 'Oman', KW: 'Kuwait', BH: 'Bahrain', EG: 'Egypt', JO: 'Jordan', IN: 'India' };
const FURN = { full: 'Furnished', semi: 'Semi-furnished', none: 'Unfurnished' };
const TENANT = { any: 'Anyone', family: 'Family only', bachelor: 'Bachelors OK', female: 'Ladies only' };
const AMEN = { ac: 'A/C', bills: 'Bills included', wifi: 'Wi-Fi', parking: 'Parking', lift: 'Lift', pool: 'Pool', gym: 'Gym', security: 'Security', balcony: 'Balcony', kitchen: 'Kitchen', laundry: 'Laundry', metro: 'Near metro' };

const esc = (s) => String(s ?? '').replace(/[\u0000-\u0008\u000B-\u001F\u007F\u202A-\u202E\u2066-\u2069]/g, '')
  .replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clean = (s, max) => String(s ?? '').replace(/[\u0000-\u001F\u007F\u202A-\u202E\u2066-\u2069]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
const titleCase = (s) => s.replace(/\b([a-z])/g, (m) => m.toUpperCase());
// Keeps Arabic and other letters (Google reads them in URLs); everything else becomes '-'.
const slug = (s) => String(s).toLowerCase().normalize('NFKC').replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 60);
const href = (u) => encodeURI(u);
const num = (n, cur) => new Intl.NumberFormat(cur === 'INR' ? 'en-IN' : 'en-US', { maximumFractionDigits: 0 }).format(n);

/* ---------- read ---------- */
function val(v) {
  if (!v || typeof v !== 'object') return null; const k = Object.keys(v)[0]; const x = v[k];
  if (k === 'stringValue' || k === 'booleanValue') return x; if (k === 'integerValue') return parseInt(x, 10); if (k === 'doubleValue') return Number(x);
  if (k === 'timestampValue') return Date.parse(x); if (k === 'arrayValue') return (x.values || []).map(val);
  if (k === 'mapValue') return Object.fromEntries(Object.entries(x.fields || {}).map(([a, b]) => [a, val(b)])); return null;
}
async function readRows() {
  if (process.env.FIXTURE) return JSON.parse(readFileSync(process.env.FIXTURE, 'utf8'));
  const url = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(PROJECT_ID)}/databases/(default)/documents:runQuery`;
  const body = { structuredQuery: { from: [{ collectionId: 'rentals' }], where: { fieldFilter: { field: { fieldPath: 'status' }, op: 'IN', value: { arrayValue: { values: [{ stringValue: 'available' }, { stringValue: 'occupied' }] } } } }, limit: 2000 } };
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
  if (!r.ok) throw new Error(`Firestore answered ${r.status}`);
  const text = await r.text(); if (text.length > 200 * 1024 * 1024) throw new Error('Response too large');
  return JSON.parse(text);
}

/* ---------- validate one listing (never trust stored data) ---------- */
function toListing(row) {
  const d = row && row.document; if (!d) return null;
  const id = String(d.name || '').split('/').pop(); if (!/^[A-Za-z0-9]{1,40}$/.test(id)) return null;
  const f = Object.fromEntries(Object.entries(d.fields || {}).map(([a, b]) => [a, val(b)]));
  if (!TYPES[f.type] || !CUR[f.country] || !(Number(f.price) > 0) || !['available', 'occupied'].includes(f.status)) return null;
  const l = {
    id, type: f.type, country: f.country, cur: CUR[f.country], price: Number(f.price), period: f.period === 'year' ? 'year' : 'month',
    cheques: Number.isInteger(f.cheques) ? f.cheques : 0, title: clean(f.title, 80) || TYPES[f.type], area: clean(f.area, 60), city: clean(f.city, 40),
    beds: Number.isInteger(f.beds) ? f.beds : 0, baths: Number.isInteger(f.baths) ? f.baths : 0, sqft: Number.isInteger(f.sqft) ? f.sqft : 0,
    furnished: FURN[f.furnished] || '', tenant: TENANT[f.tenant] || TENANT.any, commission: f.commission === true,
    amenities: (Array.isArray(f.amenities) ? f.amenities : []).filter((a) => AMEN[a]).map((a) => AMEN[a]),
    desc: String(f.desc ?? '').replace(/[\u0000-\u0009\u000B-\u001F\u007F\u202A-\u202E\u2066-\u2069]/g, '').trim().slice(0, 1500),
    lat: typeof f.lat === 'number' && Math.abs(f.lat) <= 90 ? f.lat : null, lng: typeof f.lng === 'number' && Math.abs(f.lng) <= 180 ? f.lng : null,
    status: f.status, postedAt: Number.isFinite(f.postedAt) ? f.postedAt : Date.now(), updatedAt: Number.isFinite(f.updatedAt) ? f.updatedAt : null,
    owner: clean(f.owner && f.owner.name, 50), role: clean(f.owner && f.owner.role, 20), verified: !!(f.owner && f.owner.verified === true),
    cover: null
  };
  const m = /^data:image\/jpeg;base64,([A-Za-z0-9+/]+={0,2})$/.exec(typeof f.cover === 'string' ? f.cover : '');
  if (m) { const buf = Buffer.from(m[1], 'base64'); if (buf.length > 200 && buf.length < 90000 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) l.cover = buf; }
  if (!l.area || !l.city) return null;
  l.areaSlug = slug(`${l.area} ${l.city}`) || 'area';
  l.slug = `${slug(`${TYPES[l.type]} ${l.area} ${l.city}`) || 'listing'}-${l.id.toLowerCase()}`;
  l.url = `${SITE}/rent/${l.slug}/`;
  l.monthly = l.period === 'year' ? l.price / 12 : l.price;
  return l;
}

/* ---------- page parts ---------- */
const CSS = `:root{--bg:#F3F5F3;--s:#fff;--ink:#122428;--mu:#58696B;--line:#D9E0DD;--brand:#0F5257;--soft:#DDEDE9;--sun:#E0902A;--wa:#178A45}
@media(prefers-color-scheme:dark){:root{--bg:#0C1618;--s:#132125;--ink:#E6EEEC;--mu:#92A5A6;--line:#26393D;--brand:#56B8B1;--soft:#173634;--wa:#2BBF66;color-scheme:dark}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.55 'IBM Plex Sans Arabic','Segoe UI',system-ui,sans-serif}
a{color:var(--brand)}h1,h2{font-family:'Readex Pro','Segoe UI',system-ui,sans-serif;letter-spacing:-.01em;margin:0;text-wrap:balance}
.wrap{max-width:860px;margin:0 auto;padding:0 max(16px,env(safe-area-inset-left)) 40px max(16px,env(safe-area-inset-right))}
header{background:var(--s);border-bottom:1px solid var(--line)}header .wrap{display:flex;align-items:center;justify-content:space-between;gap:12px;padding-top:12px;padding-bottom:12px}
.logo{display:flex;align-items:center;gap:8px;font:700 20px 'Readex Pro',system-ui,sans-serif;color:var(--ink);text-decoration:none}.logo b{width:30px;height:30px;border-radius:9px;background:var(--brand);display:grid;place-items:center;color:#fff;font-size:15px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:46px;padding:0 18px;border-radius:12px;font:600 15px 'Readex Pro',system-ui,sans-serif;text-decoration:none;border:1px solid transparent}
.b1{background:var(--brand);color:#fff}.b2{background:var(--wa);color:#fff}.b3{background:var(--s);color:var(--ink);border-color:var(--line)}
.crumbs{font-size:13px;color:var(--mu);margin:16px 0 10px}.crumbs a{color:var(--mu)}
.photo{width:100%;height:auto;aspect-ratio:16/10;object-fit:cover;border-radius:16px;background:var(--soft);display:block}
.price{font:700 30px 'Readex Pro',system-ui,sans-serif;margin:14px 0 2px}.price span{font:400 15px system-ui,sans-serif;color:var(--mu)}
.tags{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0}.tag{background:var(--soft);color:var(--brand);border-radius:8px;padding:3px 9px;font-size:13px;font-weight:600}.tag.off{background:#F8E6E2;color:#B23F2C}
dl{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin:16px 0}dl div{background:var(--s);border:1px solid var(--line);border-radius:12px;padding:10px 12px}dt{font-size:12px;color:var(--mu)}dd{margin:2px 0 0;font-weight:600}
.sec{margin-top:22px}.sec h2{font-size:13px;text-transform:uppercase;letter-spacing:.08em;color:var(--mu);margin-bottom:8px}
.cta{display:flex;flex-wrap:wrap;gap:10px;margin:22px 0}.cta .btn{flex:1 1 220px}
.note{background:var(--s);border:1px solid var(--line);border-radius:12px;padding:12px 14px;font-size:14px;color:var(--mu)}
.list{display:grid;gap:12px;margin-top:14px}.item{display:flex;gap:12px;background:var(--s);border:1px solid var(--line);border-radius:14px;padding:10px;text-decoration:none;color:var(--ink)}
.item img,.item .ph{width:110px;height:84px;border-radius:10px;object-fit:cover;flex:none;background:var(--soft)}.item b{font:700 17px 'Readex Pro',system-ui,sans-serif}.item small{display:block;color:var(--mu)}
footer{border-top:1px solid var(--line);margin-top:30px;padding-top:16px;font-size:13px;color:var(--mu)}footer a{color:var(--mu);margin-inline-end:14px}`;

const CSP = `default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; base-uri 'none'; form-action 'none'; upgrade-insecure-requests`;
function shell({ title, desc, canonical, image, jsonld, body, noindex }) {
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta http-equiv="Content-Security-Policy" content="${CSP}">
<meta name="referrer" content="strict-origin-when-cross-origin">
<title>${esc(title)}</title><meta name="description" content="${esc(desc)}">
<link rel="canonical" href="${esc(canonical)}">${noindex ? '\n<meta name="robots" content="noindex,follow">' : ''}
<meta name="theme-color" content="#0F5257"><link rel="icon" type="image/png" href="/icon-192.png">
<meta property="og:type" content="website"><meta property="og:site_name" content="Reedbi"><meta property="og:url" content="${esc(canonical)}">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:image" content="${esc(image)}">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:image" content="${esc(image)}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Readex+Pro:wght@600;700&family=IBM+Plex+Sans+Arabic:wght@400;600&display=swap">
<style>${CSS}</style>
<script type="application/ld+json">${JSON.stringify(jsonld).replace(/</g, '\\u003c')}</script>
</head><body>
<header><div class="wrap"><a class="logo" href="/"><b>⌂</b>Reedbi</a><a class="btn b1" href="/">Open the live map</a></div></header>
<main class="wrap">${body}
<footer>© ${new Date().getFullYear()} Reedbi Ecommerce Pvt Ltd · <a href="/">reedbi.com</a><a href="/rent/">All areas</a><a href="https://www.instagram.com/reedbi_private_limited/" rel="noopener">Instagram</a><br>Stay safe: view the place before you pay any deposit, and never send money to someone you have not met.</footer>
</main></body></html>
`;
}
const priceLine = (l) => `${l.cur} ${num(l.price, l.cur)}<span> /${l.period}</span>`;
const thumb = (l) => l.cover ? `<img src="cover.jpg" alt="">` : '';

function listingPage(l, near) {
  const type = TYPES[l.type]; const where = `${titleCase(l.area)}, ${titleCase(l.city)}`;
  const title = `${type} for rent in ${where} – ${l.cur} ${num(l.price, l.cur)}/${l.period} | Reedbi`;
  const desc = clean(`${type} for rent in ${where}, ${COUNTRY[l.country]}. ${l.cur} ${num(l.price, l.cur)} per ${l.period}${l.period === 'year' ? ` (about ${l.cur} ${num(Math.round(l.monthly), l.cur)} a month)` : ''}. ${l.furnished ? l.furnished + '. ' : ''}${l.tenant}. ${l.commission ? '' : 'No commission. '}${l.desc}`, 300);
  const facts = [['Property', type], ['Beds', l.beds || '—'], ['Baths', l.baths || '—'], ['Size', l.sqft ? `${num(l.sqft)} sq ft` : '—'], ['Furnishing', l.furnished || '—'], ['Who can rent', l.tenant], ['Rent paid', l.period === 'year' ? `Yearly${l.cheques ? `, ${l.cheques} cheque${l.cheques > 1 ? 's' : ''}` : ''}` : 'Monthly'], ['Commission', l.commission ? 'Applies' : 'None']];
  const occupied = l.status !== 'available';
  const appLink = `${SITE}/#l-${l.id}`;
  const share = `https://wa.me/?text=${encodeURIComponent(`${type} for rent in ${where} – ${l.cur} ${num(l.price, l.cur)}/${l.period}\n${l.url}`)}`;
  const jsonld = { '@context': 'https://schema.org', '@graph': [
    { '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Reedbi', item: `${SITE}/` }, { '@type': 'ListItem', position: 2, name: 'Rentals', item: `${SITE}/rent/` }, { '@type': 'ListItem', position: 3, name: where, item: `${SITE}/rent/area/${l.areaSlug}/` }, { '@type': 'ListItem', position: 4, name: type, item: l.url }] },
    { '@type': 'RealEstateListing', name: `${type} for rent in ${where}`, url: l.url, datePosted: new Date(l.postedAt).toISOString(), description: desc,
      ...(l.cover ? { image: `${l.url}cover.jpg` } : {}),
      offers: { '@type': 'Offer', price: l.price, priceCurrency: l.cur, availability: occupied ? 'https://schema.org/SoldOut' : 'https://schema.org/InStock', businessFunction: 'http://purl.org/goodrelations/v1#LeaseOut' },
      about: { '@type': ['studio', 'room', 'bedspace', 'partition'].includes(l.type) ? 'Room' : l.type === 'villa' ? 'House' : 'Apartment',
        address: { '@type': 'PostalAddress', addressLocality: titleCase(l.area), addressRegion: titleCase(l.city), addressCountry: l.country },
        ...(l.lat != null ? { geo: { '@type': 'GeoCoordinates', latitude: +l.lat.toFixed(4), longitude: +l.lng.toFixed(4) } } : {}),
        ...(l.beds ? { numberOfBedrooms: l.beds } : {}), ...(l.baths ? { numberOfBathroomsTotal: l.baths } : {}),
        ...(l.sqft ? { floorSize: { '@type': 'QuantitativeValue', value: l.sqft, unitCode: 'FTK' } } : {}),
        amenityFeature: l.amenities.map((a) => ({ '@type': 'LocationFeatureSpecification', name: a, value: true })) } } ] };
  const body = `
<nav class="crumbs"><a href="/">Reedbi</a> › <a href="/rent/">Rentals</a> › <a href="/rent/area/${esc(l.areaSlug)}/">${esc(where)}</a></nav>
${l.cover ? `<img class="photo" src="cover.jpg" alt="${esc(`${type} in ${where}`)}" width="960" height="600">` : ''}
<div class="price">${priceLine(l)}</div>
${l.period === 'year' ? `<div style="color:var(--mu)">About ${l.cur} ${num(Math.round(l.monthly), l.cur)} a month</div>` : ''}
<h1 style="font-size:24px;margin-top:6px">${esc(l.title)}</h1>
<div style="color:var(--mu);margin-top:4px">${esc(type)} for rent in ${esc(where)}</div>
<div class="tags">${occupied ? '<span class="tag off">Taken</span>' : '<span class="tag">Available</span>'}${l.commission ? '' : '<span class="tag">No commission</span>'}${l.verified ? '<span class="tag">Verified owner</span>' : ''}${l.furnished ? `<span class="tag">${esc(l.furnished)}</span>` : ''}</div>
${occupied ? '<p class="note">This place has been rented. See similar places nearby below, or open the live map.</p>' : ''}
<div class="cta"><a class="btn b2" href="${esc(appLink)}">Chat with the ${esc(l.role === 'agent' ? 'agent' : 'owner')} on WhatsApp</a><a class="btn b3" href="${esc(appLink)}">See it on the map</a><a class="btn b3" href="${esc(share)}" rel="noopener">Share</a></div>
<dl>${facts.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>
${l.amenities.length ? `<section class="sec"><h2>What it has</h2><div class="tags">${l.amenities.map((a) => `<span class="tag">${esc(a)}</span>`).join('')}</div></section>` : ''}
${l.desc ? `<section class="sec"><h2>About this place</h2><p style="white-space:pre-line;margin:0">${esc(l.desc)}</p></section>` : ''}
<section class="sec"><h2>Location</h2><p style="margin:0">${esc(where)}, ${esc(COUNTRY[l.country])}. The exact pin is on the <a href="${esc(appLink)}">Reedbi map</a>.</p></section>
<p class="note" style="margin-top:18px">Posted ${esc(new Date(l.postedAt).toISOString().slice(0, 10))}${l.owner ? ` by ${esc(l.owner)}` : ''}. Reference ${esc(l.id)}.</p>
${near.length ? `<section class="sec"><h2>More places in ${esc(titleCase(l.area))}</h2><div class="list">${near.map(itemLink).join('')}</div></section>` : ''}`;
  return shell({ title, desc, canonical: l.url, image: l.cover ? `${l.url}cover.jpg` : `${SITE}/og.png`, jsonld, body, noindex: occupied });
}
function itemLink(l) {
  return `<a class="item" href="/rent/${esc(l.slug)}/">${l.cover ? `<img src="/rent/${esc(l.slug)}/cover.jpg" alt="" loading="lazy">` : '<span class="ph"></span>'}<span><b>${l.cur} ${num(l.price, l.cur)}</b> <small style="display:inline">/${l.period}</small><span style="display:block;font-weight:600">${esc(TYPES[l.type])} · ${esc(titleCase(l.area))}</span><small>${esc(l.title)}${l.status !== 'available' ? ' · Taken' : ''}</small></span></a>`;
}
function areaPage(slugA, items) {
  const a = items[0]; const where = `${titleCase(a.area)}, ${titleCase(a.city)}`;
  const types = [...new Set(items.map((l) => TYPES[l.type]))].slice(0, 4).join(', ');
  const low = Math.min(...items.map((l) => l.monthly));
  const title = `Rooms, bed spaces and flats for rent in ${where} | Reedbi`;
  const desc = `${items.length} place${items.length > 1 ? 's' : ''} for rent in ${where}: ${types}. From ${a.cur} ${num(Math.round(low), a.cur)} a month. Chat with owners on WhatsApp, no sign-up.`;
  const url = `${SITE}/rent/area/${slugA}/`;
  const jsonld = { '@context': 'https://schema.org', '@type': 'ItemList', name: `Rentals in ${where}`, url, numberOfItems: items.length, itemListElement: items.slice(0, 100).map((l, i) => ({ '@type': 'ListItem', position: i + 1, url: l.url })) };
  const body = `<nav class="crumbs"><a href="/">Reedbi</a> › <a href="/rent/">Rentals</a> › ${esc(where)}</nav>
<h1 style="font-size:26px">Rooms, bed spaces and flats for rent in ${esc(where)}</h1>
<p style="color:var(--mu)">${esc(desc)}</p><div class="cta"><a class="btn b1" href="/?q=${encodeURIComponent(a.area)}">Show ${esc(titleCase(a.area))} on the live map</a></div>
<div class="list">${items.map(itemLink).join('')}</div>`;
  return shell({ title, desc, canonical: url, image: `${SITE}/og.png`, jsonld, body });
}
function indexPage(groups) {
  const url = `${SITE}/rent/`; const total = groups.reduce((s, g) => s + g[1].length, 0);
  const title = 'Rentals by area: rooms, bed spaces and flats | Reedbi'; const desc = `${total} places for rent across ${groups.length} areas in the UAE, the Gulf and India. Chat with owners on WhatsApp.`;
  const byCountry = {}; for (const [s, items] of groups) (byCountry[items[0].country] ||= []).push([s, items]);
  const body = `<nav class="crumbs"><a href="/">Reedbi</a> › Rentals</nav><h1 style="font-size:26px">Rentals by area</h1><p style="color:var(--mu)">${esc(desc)}</p>
${Object.entries(byCountry).map(([c, list]) => `<section class="sec"><h2>${esc(COUNTRY[c])}</h2><div class="tags">${list.map(([s, items]) => `<a class="tag" style="text-decoration:none" href="/rent/area/${esc(s)}/">${esc(titleCase(items[0].area))}, ${esc(titleCase(items[0].city))} (${items.length})</a>`).join('')}</div></section>`).join('')}`;
  return shell({ title, desc, canonical: url, image: `${SITE}/og.png`, jsonld: { '@context': 'https://schema.org', '@type': 'CollectionPage', name: 'Rentals by area', url }, body });
}

/* ---------- write ---------- */
const rows = await readRows();
const seenIds = new Set();
const listings = (Array.isArray(rows) ? rows : []).slice(0, 5000).map(toListing).filter((l) => l && !seenIds.has(l.id) && seenIds.add(l.id)).sort((a, b) => b.postedAt - a.postedAt);
// Remember what the last sitemap said, so only new or changed pages are announced.
const oldMap = new Map(); try { for (const m of readFileSync(join(SITE_DIR, 'sitemap.xml'), 'utf8').matchAll(/<loc>([^<]+)<\/loc><lastmod>([^<]+)<\/lastmod>/g)) oldMap.set(m[1], m[2]); } catch {}
if (!listings.length && !process.env.ALLOW_EMPTY && existsSync(join(OUT, 'index.html'))) { console.log('No listings returned; keeping existing pages.'); process.exit(0); }
rmSync(OUT, { recursive: true, force: true }); mkdirSync(OUT, { recursive: true });

const areas = new Map(); for (const l of listings) { if (!areas.has(l.areaSlug)) areas.set(l.areaSlug, []); areas.get(l.areaSlug).push(l); }
const live = (l) => l.status === 'available';
for (const l of listings) {
  const dir = join(OUT, l.slug); mkdirSync(dir, { recursive: true });
  if (l.cover) writeFileSync(join(dir, 'cover.jpg'), l.cover);
  const near = (areas.get(l.areaSlug) || []).filter((x) => x.id !== l.id && live(x)).slice(0, 6);
  writeFileSync(join(dir, 'index.html'), listingPage(l, near));
}
const groups = [...areas.entries()].sort((a, b) => b[1].length - a[1].length);
for (const [s, items] of groups) { const dir = join(OUT, 'area', s); mkdirSync(dir, { recursive: true }); writeFileSync(join(dir, 'index.html'), areaPage(s, items)); }
writeFileSync(join(OUT, 'index.html'), indexPage(groups));

const iso = (t) => new Date(t).toISOString().slice(0, 10);
const urls = [[`${SITE}/`, iso(Date.now()), 'hourly', '1.0'], [`${SITE}/rent/`, iso(Date.now()), 'hourly', '0.9'],
  ...groups.map(([s, items]) => [`${SITE}/rent/area/${s}/`, iso(Math.max(...items.map((l) => l.updatedAt || l.postedAt))), 'daily', '0.8']),
  ...listings.filter(live).map((l) => [l.url, iso(l.updatedAt || l.postedAt), 'weekly', '0.7'])];
writeFileSync(join(SITE_DIR, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(([u, d, f, p]) => `  <url><loc>${esc(href(u))}</loc><lastmod>${d}</lastmod><changefreq>${f}</changefreq><priority>${p}</priority></url>`).join('\n')}\n</urlset>\n`);
// llms.txt: a plain summary for AI assistants (optional convention, harmless)
writeFileSync(join(SITE_DIR, 'llms.txt'), `# Reedbi\n\n> Rooms, bed spaces, partitions, studios and flats for rent in the UAE, the Gulf and India, posted by owners and shown on a live map. Visitors chat with owners on WhatsApp; there is no sign-up to browse.\n\n- Live map and search: ${SITE}/\n- All rentals by area: ${SITE}/rent/\n- Sitemap of every listing: ${SITE}/sitemap.xml\n\n## Areas\n\n${groups.slice(0, 200).map(([s, items]) => `- [${titleCase(items[0].area)}, ${titleCase(items[0].city)}](${href(`${SITE}/rent/area/${s}/`)}): ${items.filter(live).length} available, from ${items[0].cur} ${num(Math.round(Math.min(...items.map((l) => l.monthly))), items[0].cur)} a month`).join('\n')}\n`);

// IndexNow: tells Bing (which feeds ChatGPT search and Copilot), Yandex, Seznam and Naver about
// new or changed pages within minutes. The key is public by design; it only proves site ownership.
const changed = urls.filter(([u, d]) => oldMap.get(href(u)) !== d).map(([u]) => href(u)).slice(0, 10000);
const KEY = process.env.INDEXNOW_KEY || '';
if (KEY && /^[a-f0-9]{32}$/.test(KEY) && changed.length && !process.env.FIXTURE) {
  try {
    const r = await fetch('https://api.indexnow.org/indexnow', { method: 'POST', headers: { 'Content-Type': 'application/json; charset=utf-8' }, signal: AbortSignal.timeout(20000),
      body: JSON.stringify({ host: new URL(SITE).host, key: KEY, keyLocation: `${SITE}/${KEY}.txt`, urlList: changed }) });
    console.log(`IndexNow: sent ${changed.length} URLs, answer ${r.status}`);
  } catch (e) { console.log('IndexNow not reached:', e.message); }
}
console.log(`Built ${listings.length} listing pages, ${groups.length} area pages, sitemap with ${urls.length} URLs (${changed.length} new or changed).`);
